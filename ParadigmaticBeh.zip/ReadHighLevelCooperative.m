Values = zeros(120,10);
Beliefs = zeros(3,3,10,120);
BeliefVariance=zeros(3,3,18);
IndividualProbability = zeros(3,3,10,120);
Output = zeros(48,10);
load('HighLevelCoop.mat');

Output(1,:)=mean(Values(2*(1:60)-1,:));
Output(2,:)=std(Values(2*(1:60)-1,:));
Output(3,:)=mean(Values(2*(1:60),:));
Output(4,:)=std(Values(2*(1:60),:));

 Gra=errorbar(transpose([Output(1,:);Output(3,:)]),transpose([Output(2,:);Output(4,:)]),'DisplayName','Output(1,:)', 'LineWidth', 3,'YDataSource','Output(1,:)');figure(gcf);
axis( [1 10 0 1] );
box off;
xlabel('Round Number', 'fontsize', 50, 'FontName', 'Times');
ylabel('Average Percentage sent', 'fontsize', 50, 'FontName', 'Times');
set(gca, 'YTick', [0 0.25 0.5 0.75 1]);
Graph = get(Gra, 'Child');
set(Graph{1,1}(2),'color',[0 0 0]);
set(Graph{2,1}(1),'color',[1 0 0]); 
set(Graph{2,1}(2),'color',[0 0 0]);
