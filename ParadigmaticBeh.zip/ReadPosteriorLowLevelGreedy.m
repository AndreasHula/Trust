Values = zeros(120,10);
Beliefs = zeros(3,3,10,120);
BeliefVariance=zeros(3,3,18);
IndividualProbability = zeros(3,3,10,120);
load('PosteriorLowLevelGreedy.mat');
colormap winter;

I2 = subplot(2,2,1);barwitherr(Output(20:23,1:3),Output(12:15,1:3));
I0 = subplot(2,2,2);barwitherr(Output(20:23,7:9),Output(12:15,7:9));
T1 = subplot(2,2,3);barwitherr(Output(24:27,4:6),Output(16:19,4:6));
T0 = subplot(2,2,4);barwitherr(Output(24:27,7:9),Output(16:19,7:9));
