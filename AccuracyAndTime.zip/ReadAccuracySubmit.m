%Matlab Readout script by A. Hula - 8.Sept.2014
%Accuracy and Running Time estimation readout.
%120 pairs per setting from 2500 to 50000 paths
%This data underlies figure 12 in the manuscript.
Values = zeros(1920,8); %Chosen actions during simulations
QValues = zeros(5,180,8); %Action Probability
QTValues = zeros(5,180,8); %Response Probability
QITValues = zeros(5,180, 3,8); %Believed Response Probability by L2 investor
QCovar = zeros(5,5,7,8); %Sample Covariances of initial action probabilities
Time = zeros(1080, 8); %Calculation Time for First action

for k =0:7
    fid = fopen(['ModifiedAccuracy' int2str(k) 'C25.bin'],'r');
    for i = 1:960
        for s = 1:5
            QValues(s,i,  k+1)=fread(fid,1,'double');
        end
        Values(2*(i-1)+1, k+1)= 1/4*fread(fid,1,'int32');
        if Values(2*(i-1)+1, k+1)>0
            for s = 1:5
               QTValues(s,i,  k+1) =fread(fid,1,'double');
            end           
            Values(2*(i), k+1)=1/6*fread(fid,1,'int32');
            for b = 1:3
                for s = 1:5
                    QITValues(s,i, b, k+1) =fread(fid,1,'double');
                end
            end
        else
            Values(2*(i), k+1)=1/6*fread(fid,1,'int32');     
        end               
        Time(i,  k+1) = fread(fid,1,'double');
    end
    fclose(fid);
end

QMean = zeros(5,8);

load('QReference.mat'); %Reference Value: Action Probability for 10^6 simulated paths, single subject
for k =1:8
    for i =1 :5
        QMean(i,k) = Reference(i,k,1);
    end
end
    
CovarNorm = zeros(8,8);
NormTime = zeros(8,8);
for k = 1:8
    for s =1:8
        for i = 1:5
            for j = 1:5
                QCovar(i,j,k, s) = 1/119*sum((QValues(i,((k-1)*120+1):(k*120), s)-QMean(i,s)).*(QValues(j,((k-1)*120+1):(k*120), s)-QMean(j,s)));
            end
        end
        CovarNorm(9-k, s) = sum(sum(QCovar(:,:,k, s).^2));
        NormTime(9-k, s) = mean(Time(((k-1)*120+1):(k*120),s));
    end
end