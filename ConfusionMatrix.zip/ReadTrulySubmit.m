%8.Sept.2014 - Script to create Fig 10 (Confusion Matrix)
%By Andreas Hula
InvestorLikelihoods=zeros(1,105, 9); %Subject Wise
InvestorToM=zeros(1,105); %Subject Wise
InvestorGuilt=zeros(1,105); %Subject Wise
InvestorPlan=zeros(1,105); %Subject Wise
TrusteeLikelihoods=zeros(1,105, 9); %Subject Wise
TrusteeToM=zeros(1,105); %Subject Wise
TrusteeGuilt=zeros(1,105); %Subject Wise
TrusteePlan=zeros(1,105); %Subject Wise
InvestorBelief=zeros(3,3,10,105, 9); %Beliefs Subject Wise for every time
                                 %Parameters: (ToM level, Believed Guilt,
                                 %time step, subject number)
TrusteeBelief=zeros(3,3,10,105, 9); %Beliefs Subject Wise for every time
                                 %Parameters: (ToM level, Believed Guilt,
                                 %time step, subject number)
InvestorLikelihoodsCompl=zeros(1,120, 9); %Subject Wise
InvestorToMCompl=zeros(1,120); %Subject Wise
InvestorGuiltCompl=zeros(1,120); %Subject Wise
InvestorPlanCompl=zeros(1,120); %Subject Wise
TrusteeLikelihoodsCompl=zeros(1,120, 9); %Subject Wise
TrusteeToMCompl=zeros(1,120); %Subject Wise
TrusteeGuiltCompl=zeros(1,120); %Subject Wise
TrusteePlanCompl=zeros(1,120); %Subject Wise
InvestorBeliefCompl=zeros(3,3,10,120, 9); %Beliefs Subject Wise for every time
                                 %Parameters: (ToM level, Believed Guilt,
                                 %time step, subject number)
TrusteeBeliefCompl=zeros(3,3,10,120, 9); %Beliefs Subject Wise for every time
                                 %Parameters: (ToM level, Believed Guilt,
                                 %time step, subject number)                                 
ResultComplement = zeros(120,6,9);
ValuesComplement = zeros(240,10, 9);
ValidationComplement = zeros(120,6, 9);
ComparisonComplement = zeros(120,6, 9);
Result = zeros(105,6,9);
Values = zeros(210,10, 9);
Validation = zeros(105,6, 9);
Comparison = zeros(105,6, 9);
GuiltCounts = zeros(3,3);
ToMCounts = zeros(2,2);
PlanCounts = zeros(3,3);
TGuiltCounts = zeros(3,3);
TToMCounts = zeros(2,2);
TPlanCounts = zeros(3,3);
InversePlan = [1 0 2 0 0 0 0 3];
for k = 0:8
    fid =fopen(['Truly' int2str(k) 'Complement.bin'], 'r');
    for j = 1:120
        InvestorLikelihoodsCompl(1,j, k+1)=fread(fid,1,'double');
        InvestorToMCompl(1,j)=fread(fid,1,'int32');
        InvestorGuiltCompl(1,j)=fread(fid,1,'int32');
        InvestorPlanCompl(1,j)=fread(fid,1,'int32');
        TrusteeLikelihoodsCompl(1,j, k+1)=fread(fid,1,'double');
        TrusteeToMCompl(1,j)=fread(fid,1,'int32');
        TrusteeGuiltCompl(1,j)=fread(fid,1,'int32');
        TrusteePlanCompl(1,j)=fread(fid,1,'int32');
        for t = 1:10
            for s=1:3
                for g =1:3
                    InvestorBeliefCompl(s,g,t,j, k+1)=fread(fid,1,'double');
                end
            end
        end
        for t = 1:10
            for s=1:3
                for g =1:3
                    TrusteeBeliefCompl(s,g,t,j, k+1)=fread(fid,1,'double');
                end
            end
        end   
    end
    fclose(fid);


    ComparisonComplement(:,1,k+1)= InvestorGuiltCompl;
    ComparisonComplement(:,2,k+1)=InvestorPlanCompl;
    ComparisonComplement(:,3,k+1)=InvestorToMCompl;
    ComparisonComplement(:,4,k+1)=TrusteeGuiltCompl;
    ComparisonComplement(:,5,k+1)=TrusteePlanCompl;
    ComparisonComplement(:,6,k+1)=TrusteeToMCompl;


    fid = fopen(['3ValidationComplement' int2str(k) '.bin'],'r');
    for i = 1:120
        for j = 1:6
            ValidationComplement(i,j, k+1) =fread(fid, 1,'int32');
        end
    end
    fclose(fid);
    
    for i = 1:120  
        GuiltCounts(ValidationComplement(i,1,k+1)+1,ComparisonComplement(i,1,k+1)+1)= GuiltCounts(ValidationComplement(i,1,k+1)+1,ComparisonComplement(i,1,k+1)+1)+1;
        PlanCounts(InversePlan(ValidationComplement(i,2,k+1)+1),InversePlan(ComparisonComplement(i,2,k+1)+1))=PlanCounts(InversePlan(ValidationComplement(i,2,k+1)+1),InversePlan(ComparisonComplement(i,2,k+1)+1))+1;
        ToMCounts(ValidationComplement(i,3,k+1)/2+1, ComparisonComplement(i,3,k+1)/2+1)=ToMCounts(ValidationComplement(i,3,k+1)/2+1, ComparisonComplement(i,3,k+1)/2+1)+1;
        TGuiltCounts(ValidationComplement(i,4,k+1)+1,ComparisonComplement(i,4,k+1)+1)=TGuiltCounts(ValidationComplement(i,4, k+1)+1,ComparisonComplement(i,4, k+1)+1)+1;
        TPlanCounts(InversePlan(ValidationComplement(i,5, k+1)+1),InversePlan(ComparisonComplement(i,5, k+1)+1))=TPlanCounts(InversePlan(ValidationComplement(i,5,k+1)+1),InversePlan(ComparisonComplement(i,5, k+1)+1))+1;    
        TToMCounts(ValidationComplement(i,6, k+1)+1, ComparisonComplement(i,6, k+1)+1)=TToMCounts(ValidationComplement(i,6, k+1)+1, ComparisonComplement(i,6, k+1)+1)+1;        
    end

    ResultComplement(:,:,k+1) = ValidationComplement(:,:,k+1) -ComparisonComplement(:,:,k+1);

    fid = fopen(['TrulyFinalGenerative' int2str(k) 'Compl.bin'],'r');
        for i = 1:120
            for j = 1:10
                ValuesComplement(2*(i-1)+1,j, k+1)= 1/4*fread(fid,1,'int32');
                ValuesComplement(2*(i),j, k+1)=1/6*fread(fid,1,'int32');
            end
        end
    fclose(fid);
    fid =fopen(['Truly' int2str(k) '.bin'], 'r');
    for j = 1:105
        InvestorLikelihoods(1,j, k+1)=fread(fid,1,'double');
        InvestorToM(1,j)=fread(fid,1,'int32');
        InvestorGuilt(1,j)=fread(fid,1,'int32');
        InvestorPlan(1,j)=fread(fid,1,'int32');
        TrusteeLikelihoods(1,j, k+1)=fread(fid,1,'double');
        TrusteeToM(1,j)=fread(fid,1,'int32');
        TrusteeGuilt(1,j)=fread(fid,1,'int32');
        TrusteePlan(1,j)=fread(fid,1,'int32');
        for t = 1:10
            for s=1:3
                for g =1:3
                    InvestorBelief(s,g,t,j, k+1)=fread(fid,1,'double');
                end
            end
        end
        for t = 1:10
            for s=1:3
                for g =1:3
                    TrusteeBelief(s,g,t,j, k+1)=fread(fid,1,'double');
                end
            end
        end   
    end
    fclose(fid);


    Comparison(:,1,k+1)= InvestorGuilt;
    Comparison(:,2,k+1)=InvestorPlan;
    Comparison(:,3,k+1)=InvestorToM;
    Comparison(:,4,k+1)=TrusteeGuilt;
    Comparison(:,5,k+1)=TrusteePlan;
    Comparison(:,6,k+1)=TrusteeToM;


    fid = fopen(['3Validation' int2str(k) '.bin'],'r');
    for i = 1:105
        for j = 1:6
            Validation(i,j, k+1) =fread(fid, 1,'int32');
        end
    end
    fclose(fid);
    for i = 1:105  
        GuiltCounts(Validation(i,1, k+1)+1,Comparison(i,1, k+1)+1)= GuiltCounts(Validation(i,1, k+1)+1,Comparison(i,1, k+1)+1)+1;
        PlanCounts(InversePlan(Validation(i,2, k+1)+1),InversePlan(Comparison(i,2, k+1)+1))=PlanCounts(InversePlan(Validation(i,2, k+1)+1),InversePlan(Comparison(i,2, k+1)+1))+1;
        ToMCounts(Validation(i,3, k+1)/2+1, Comparison(i,3, k+1)/2+1)=ToMCounts(Validation(i,3, k+1)/2+1, Comparison(i,3, k+1)/2+1)+1;
        TGuiltCounts(Validation(i,4, k+1)+1,Comparison(i,4, k+1)+1)=TGuiltCounts(Validation(i,4, k+1)+1,Comparison(i,4, k+1)+1)+1;
        TPlanCounts(InversePlan(Validation(i,5, k+1)+1),InversePlan(Comparison(i,5, k+1)+1))=TPlanCounts(InversePlan(Validation(i,5, k+1)+1),InversePlan(Comparison(i,5, k+1)+1))+1;    
        TToMCounts(Validation(i,6, k+1)+1, Comparison(i,6, k+1)+1)=TToMCounts(Validation(i,6, k+1)+1, Comparison(i,6, k+1)+1)+1;        
    end
    Result(:,:,k+1) = Validation(:,:,k+1) -Comparison(:,:,k+1);

    fid = fopen(['TrulyFinalGenerative' int2str(k) '.bin'],'r');
        for i = 1:105
            for j = 1:10
                Values(2*(i-1)+1,j, k+1)= 1/4*fread(fid,1,'int32');
                Values(2*(i),j, k+1)=1/6*fread(fid,1,'int32');
            end
        end
    fclose(fid);

end
Guiltsum = sum(GuiltCounts,2);
TGuiltsum = sum(TGuiltCounts,2);
GuiltConfusion = zeros(3,3);
TGuiltConfusion = zeros(3,3);
Plansum = sum(PlanCounts,2);
TPlansum = sum(TPlanCounts,2);
PlanConfusion = zeros(3,3);
TPlanConfusion = zeros(3,3);
ToMsum = sum(ToMCounts,2);
TToMsum = sum(TToMCounts,2);
ToMConfusion = zeros(2,2);
TToMConfusion = zeros(2,2);
for i = 1:3
    GuiltConfusion(i,:) = GuiltCounts(i,:)/Guiltsum(i);
    TGuiltConfusion(i,:) = TGuiltCounts(i,:)/TGuiltsum(i);   
    PlanConfusion(i,:) = PlanCounts(i,:)/Plansum(i);
    TPlanConfusion(i,:) =TPlanCounts(i,:)/TPlansum(i);
end
 GuiltConfusion = transpose(GuiltConfusion);
 TGuiltConfusion = transpose(TGuiltConfusion); 
 PlanConfusion = transpose(PlanConfusion);
 TPlanConfusion = transpose(TPlanConfusion); 
for i=1:2
    ToMConfusion(i,:) = ToMCounts(i,:)/ToMsum(i);
    TToMConfusion(i,:) = TToMCounts(i,:)/TToMsum(i);
end
 ToMConfusion = transpose(ToMConfusion);
 TToMConfusion = transpose(TToMConfusion); 