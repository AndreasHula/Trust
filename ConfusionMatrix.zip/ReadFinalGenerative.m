Values = zeros(210,10);
Beliefs = zeros(3,3,10,120);
BeliefVariance=zeros(3,3,18);
IndividualProbability = zeros(3,3,10,120);
Output = zeros(48,10);
fid = fopen('TrulyFinalGenerative7.bin','r');
    for i = 1:105
        for j = 1:10
           Values(2*(i-1)+1,j)= 1/4*fread(fid,1,'int32');
           Values(2*(i),j)=1/6*fread(fid,1,'int32');
        end
      
    end

fclose(fid);

