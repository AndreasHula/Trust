Validation = zeros(105,6);
fid = fopen('3Validation0.bin','r');
for i = 1:105
    for j = 1:6
        Validation(i,j) =fread(fid, 1,'int32');
    end
end
fclose(fid);